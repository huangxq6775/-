# 声译 · LingoLive

原生 Android 实时语音翻译 APP，支持中文、英语、日语、韩语、法语、德语、西班牙语、印地语（हिन्दी / hi-IN）。Android 8.0（API 26）及以上，当前版本 `0.2.0-debug`。

## 使用

选择源语言和目标语言，点击「开始实时翻译」，授予麦克风权限。系统 SpeechRecognizer 提供语音识别，ML Kit 在手机上翻译。首次使用需联网下载语言模型，下载后翻译可离线；语音识别是否联网、是否支持中间结果，取决于系统语音服务。

支持语言互换、译文复制和系统 TTS 朗读。朗读前暂停麦克风，避免将自己播放的译文再次识别。最近 30 条完整译文保存在本机，支持清空，禁止备份和设备迁移。

## 悬浮窗

点击「开启悬浮翻译」，允许“显示在其他应用上层”，并授权麦克风。开启后可以切到其他 APP 查看语音译文，通知栏显示前台麦克风服务。通知中的「停止翻译」及悬浮窗右上角 × 都会关闭悬浮窗并停止聆听。

- 按住标题移动，拖动右下角 ↘ 调整窗口大小。
- 「悬浮窗与 GPT 校准设置」可调整宽度、高度、窗口明暗、字体大小及双语显示；更改即时生效并保存。
- 关闭双语显示时仅显示译文。
- 明暗调整只改变悬浮窗配色，不改变系统屏幕亮度。
- 暂停按钮停止聆听，继续按钮恢复；彻底结束请点 × 或通知的停止按钮。
- 开启悬浮窗后离开主界面会继续聆听；未开启悬浮窗时离开界面仍自动暂停。
- 划掉最近任务、关闭服务或进程被系统终止后，不会自动恢复录音。需重新打开 APP 并主动开始。

这是麦克风语音翻译，**不会读取其他 APP 的屏幕文字或内部播放音频**。部分银行、权限或安全页面禁止显示第三方悬浮窗，系统省电策略也可能影响后台语音服务。印地语识别和朗读仍需系统语音服务及相应语言包。

## GPT 译文校准（可选）

默认关闭。开启后只把完整句子的原文与本机初译发给自建服务，再调用 OpenAI 校准。不发送音频，也不会将 OpenAI API 密钥打包进 APK。

仓库附带 [Python 服务端、Dockerfile、配置模板与部署说明](server/README.md)。先部署可信 HTTPS 地址，再在手机设置中输入 `/calibrate` 地址和独立的服务访问令牌，启用开关并保存。手机令牌通过 Android Keystore 加密存储；OpenAI API 密钥只保存在服务器。

本机初译会先显示，GPT 校准成功后再替换。界面会区分「校准中」「已校准」和失败回退。超时、断网、无权限、额度不足等情况保留本机译文；切换语言、清空历史或修改 AI 配置后，过期结果不会回写。校准服务只保留最新待处理请求，避免连续说话时无限积压。

**附带服务端不等于已部署上线。** 当前环境未配置真实 OpenAI 密钥、服务访问令牌及公网 HTTPS 地址，真实 GPT 调用须部署后验证；本地测试使用替身上游，不产生 OpenAI 费用。

## 开发与构建

使用 Android Studio、JDK 17 或 21，Android SDK 35 / Build Tools 35.0.0。

```bash
./gradlew assembleDebug testDebugUnitTest lintDebug
cd server
python3 -m unittest -v test_server
```

本机 `local.properties` 设置 `sdk.dir`，该文件不提交。APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

当前 Codex 环境 SDK 为 `/workspace/android-tools/sdk`，JDK 为 `/workspace/android-tools/jdk`，可在 `/workspace/-` 执行：

```bash
JAVA_HOME=/workspace/android-tools/jdk \
JAVA_TOOL_OPTIONS='-Dhttps.proxyHost=proxy -Dhttps.proxyPort=8080 -Dhttp.proxyHost=proxy -Dhttp.proxyPort=8080 -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts' \
./gradlew --no-daemon assembleDebug testDebugUnitTest lintDebug
```

调试签名版本仅用于测试，正式上架需配置签名。Android 测试使用 Robolectric 覆盖 API 26/35 的启动、印地语切换、悬浮窗布局与显示设置；服务端测试覆盖真实本地 HTTP 路由，GPT 上游为测试替身。Docker 镜像、真实语音及 OpenAI 端到端效果尚需独立验收。

## 真机验收

1. 先验证中文 → 印地语、印地语 → 中文的识别、翻译和朗读。
2. 打开悬浮窗并切到另一个 APP，说话，确认原文和译文继续更新。
3. 拖动、缩放，调整明暗、字体和双语显示；重启后确认设置保留。
4. 暂停后确认无新音频识别；关闭窗口或点击通知停止后，确认麦克风指示结束。
5. 拒绝或撤销悬浮窗和麦克风权限，确认有提示且不自动启动录音。
6. 部署 GPT 服务，填写手机设置，说完整句子，确认本机初译先出现、GPT 成功后显示「已校准」。
7. 使用错误令牌、断开网络、切换语言、清空历史，确认失败保留初译且不会被旧校准结果覆盖。
8. 在 Android 14/15 上检查前台服务限制、通知拒绝、旋转屏幕及系统省电策略下的行为。
