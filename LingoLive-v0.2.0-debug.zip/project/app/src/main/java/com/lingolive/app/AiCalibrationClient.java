package com.lingolive.app;

import android.content.Context;
import android.os.Handler;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

final class AiCalibrationClient implements AutoCloseable {
    private static class UserVisibleError extends IOException { UserVisibleError(String message) { super(message); } }
    interface Callback { void complete(String translation, String error); }
    private final Context context;
    private final Handler handler;
    private final AtomicLong generation = new AtomicLong();
    private final ThreadPoolExecutor worker = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
        new ArrayBlockingQueue<>(1), new ThreadPoolExecutor.DiscardOldestPolicy());
    private volatile HttpURLConnection active;
    AiCalibrationClient(Context context, Handler handler) { this.context = context; this.handler = handler; }
    void cancel() {
        generation.incrementAndGet(); worker.getQueue().clear();
        HttpURLConnection connection = active;
        if (connection != null) connection.disconnect();
    }
    void calibrate(String source, String draft, String from, String to, Callback callback) {
        cancel(); long ticket = generation.get();
        AppSettings settings = new AppSettings(context);
        String endpoint = settings.endpoint();
        worker.execute(() -> {
            if (ticket != generation.get()) return;
            String translated = null, error = null;
            HttpURLConnection connection = null;
            try {
                if (!AppSettings.validEndpoint(endpoint)) throw new UserVisibleError("请配置 HTTPS 校准服务地址");
                if (source.length() > 4000 || draft.length() > 8000) throw new UserVisibleError("句子过长，跳过 AI 校准");
                String token = new SecureTokenStore(context).read();
                if (token.isEmpty()) throw new UserVisibleError("请配置校准服务访问令牌");
                JSONObject body = new JSONObject().put("source", source).put("translation", draft)
                    .put("source_language", from).put("target_language", to);
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection = (HttpURLConnection)new URL(endpoint).openConnection(); active = connection;
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(10000); connection.setReadTimeout(25000);
                connection.setRequestMethod("POST"); connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(bytes.length);
                connection.setRequestProperty("Authorization", "Bearer " + token);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int status = connection.getResponseCode();
                if (status == 401 || status == 403) throw new UserVisibleError("校准服务认证失败");
                if (status == 429) throw new UserVisibleError("校准服务繁忙，请稍后重试");
                if (status != 200) throw new UserVisibleError("校准服务暂不可用");
                try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[2048]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (out.size() + n > 65536) throw new UserVisibleError("校准服务响应过大");
                        out.write(buffer, 0, n);
                    }
                    translated = new JSONObject(out.toString("UTF-8")).getString("translation").trim();
                    if (translated.isEmpty() || translated.length() > 8000) throw new UserVisibleError("校准服务返回无效译文");
                }
            } catch (UserVisibleError e) { error = e.getMessage(); }
            catch (IOException e) { error = "GPT 校准未完成"; }
            catch (Exception e) { error = "GPT 校准配置或响应无效"; }
            finally { if (connection != null) connection.disconnect(); if (active == connection) active = null; }
            String result = translated, failure = error;
            handler.post(() -> { if (ticket == generation.get()) callback.complete(result, failure); });
        });
    }
    @Override public void close() { cancel(); worker.shutdownNow(); }
}
