package com.lingolive.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.net.URI;

final class AppSettings {
    final SharedPreferences prefs;
    AppSettings(Context context) { prefs = context.getSharedPreferences("overlay_settings", Context.MODE_PRIVATE); }
    int width() { return clamp(prefs.getInt("width", 320), 220, 600); }
    int height() { return clamp(prefs.getInt("height", 280), 180, 600); }
    int font() { return clamp(prefs.getInt("font", 20), 12, 36); }
    int brightness() { return clamp(prefs.getInt("brightness", 90), 20, 100); }
    boolean bilingual() { return prefs.getBoolean("bilingual", true); }
    boolean aiEnabled() { return prefs.getBoolean("ai_enabled", false); }
    String endpoint() { return prefs.getString("ai_endpoint", ""); }
    static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    static boolean validEndpoint(String value) {
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null
                && uri.getUserInfo() == null && uri.getRawQuery() == null && uri.getFragment() == null
                && uri.getPath().endsWith("/calibrate");
        } catch (Exception e) { return false; }
    }
}
