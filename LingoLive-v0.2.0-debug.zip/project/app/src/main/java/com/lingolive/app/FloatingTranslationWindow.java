package com.lingolive.app;

import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Draggable and resizable overlay. Touches outside the panel continue to the underlying app. */
final class FloatingTranslationWindow {
    private final TranslationService service;
    private final AppSettings settings;
    private final WindowManager manager;
    private final LinearLayout root;
    private final TextView original, translation, status;
    private final DragHandle title;
    private final Button pause;
    private WindowManager.LayoutParams params;
    private boolean attached;
    FloatingTranslationWindow(TranslationService service) {
        this.service = service; settings = new AppSettings(service);
        manager = service.getSystemService(WindowManager.class);
        root = new LinearLayout(service); root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout header = new LinearLayout(service); header.setGravity(Gravity.CENTER_VERTICAL);
        title = new DragHandle(); title.setText("声译 · 按住移动"); title.setTextSize(13); title.setTextColor(0xFF216B5A);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        Button close = new Button(service); close.setText("×"); close.setContentDescription("关闭悬浮窗并停止麦克风"); close.setMinWidth(0); close.setMinimumWidth(0);
        header.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48))); close.setOnClickListener(v -> service.end());
        root.addView(header); title.setOnTouchListener(new Drag(false));
        ScrollView scroll = new ScrollView(service); LinearLayout texts = new LinearLayout(service); texts.setOrientation(LinearLayout.VERTICAL);
        original = label("", 18); translation = label("", 20); original.setTextIsSelectable(true); translation.setTextIsSelectable(true);
        texts.addView(original); texts.addView(translation); scroll.addView(texts);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        status = label("", 11); root.addView(status);
        LinearLayout bottom = new LinearLayout(service); bottom.setGravity(Gravity.CENTER_VERTICAL);
        pause = new Button(service); pause.setTextSize(12); bottom.addView(pause, new LinearLayout.LayoutParams(0, dp(48), 1));
        pause.setOnClickListener(v -> { if (service.engine.requested) service.engine.pause(); else service.engine.begin(); });
        DragHandle resize = new DragHandle(); resize.setText("↘"); resize.setTextSize(24); resize.setGravity(Gravity.CENTER); resize.setContentDescription("拖动调整窗口大小");
        bottom.addView(resize, new LinearLayout.LayoutParams(dp(48), dp(48))); resize.setOnTouchListener(new Drag(true)); root.addView(bottom);
    }
    void show() {
        params = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = settings.prefs.getInt("x", dp(8)); params.y = settings.prefs.getInt("y", dp(90));
        applySettings();
        manager.addView(root, params); attached = true; render();
    }
    void applySettings() {
        if (params == null) return;
        params.width = Math.min(dp(settings.width()), screenWidth() - dp(16));
        params.height = Math.min(dp(settings.height()), screenHeight() - dp(48)); clampPosition();
        int shade = (int)(settings.brightness() * 2.55f);
        GradientDrawable background = new GradientDrawable(); background.setColor(Color.rgb(shade, shade, shade));
        background.setCornerRadius(dp(18)); background.setStroke(dp(1), 0xFF71827A); root.setBackground(background);
        boolean dark = settings.brightness() < 60;
        title.setTextColor(dark ? Color.WHITE : 0xFF216B5A);
        original.setTextColor(dark ? 0xFFE0E9E3 : 0xFF183B33);
        translation.setTextColor(dark ? Color.WHITE : 0xFF15513F);
        status.setTextColor(dark ? 0xFFDDDDDD : 0xFF444444);
        original.setTextSize(Math.max(12, settings.font() - 2)); translation.setTextSize(settings.font());
        original.setVisibility(settings.bilingual() ? View.VISIBLE : View.GONE);
        if (attached) manager.updateViewLayout(root, params);
        render();
    }
    void render() {
        TranslationEngine e = service.engine;
        original.setText(e.sourceText); translation.setText(e.targetText);
        status.setText(e.aiStatus.isEmpty() ? e.status : e.aiStatus);
        pause.setText(e.requested ? "暂停聆听" : "继续聆听");
    }
    void close() { if (attached) { manager.removeView(root); attached = false; } }
    private void clampPosition() {
        params.x = AppSettings.clamp(params.x, 0, Math.max(0, screenWidth() - params.width));
        params.y = AppSettings.clamp(params.y, 0, Math.max(0, screenHeight() - params.height - dp(24)));
    }
    private int screenWidth() { return service.getResources().getDisplayMetrics().widthPixels; }
    private int screenHeight() { return service.getResources().getDisplayMetrics().heightPixels; }
    private int dp(int value) { return Math.round(value * service.getResources().getDisplayMetrics().density); }
    private int toDp(int value) { return Math.round(value / service.getResources().getDisplayMetrics().density); }
    private TextView label(String value, int size) { TextView v = new TextView(service); v.setText(value); v.setTextSize(size); v.setPadding(0, dp(4), 0, dp(4)); return v; }
    // The app deliberately uses the platform Theme.Material, not an AppCompat theme.
    @android.annotation.SuppressLint("AppCompatCustomView")
    private class DragHandle extends TextView {
        DragHandle() { super(service); setClickable(true); }
        @Override public boolean performClick() { super.performClick(); return true; }
    }
    private class Drag implements View.OnTouchListener {
        final boolean resize;
        float x, y; int originalX, originalY, width, height;
        Drag(boolean resize) { this.resize = resize; }
        @Override public boolean onTouch(View view, MotionEvent event) {
            if (params == null) return false;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                x = event.getRawX(); y = event.getRawY(); originalX = params.x; originalY = params.y; width = params.width; height = params.height; return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                int dx = Math.round(event.getRawX() - x), dy = Math.round(event.getRawY() - y);
                if (resize) {
                    params.width = AppSettings.clamp(width + dx, Math.min(dp(220), screenWidth() - dp(16)), screenWidth() - dp(16));
                    params.height = AppSettings.clamp(height + dy, Math.min(dp(180), screenHeight() - dp(48)), screenHeight() - dp(48));
                } else { params.x = originalX + dx; params.y = originalY + dy; }
                clampPosition(); manager.updateViewLayout(root, params); return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                settings.prefs.edit().putInt("width", toDp(params.width)).putInt("height", toDp(params.height))
                    .putInt("x", params.x).putInt("y", params.y).apply();
                view.performClick(); return true;
            }
            return false;
        }
    }
}
