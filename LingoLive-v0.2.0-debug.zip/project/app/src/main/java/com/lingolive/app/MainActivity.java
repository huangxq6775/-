package com.lingolive.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = 0xFF216B5A, INK = 0xFF183B33, MUTED = 0xFF71827A;
    private static final String[] NAMES = TranslationEngine.NAMES;
    private static final String[] LOCALES = TranslationEngine.LOCALES;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<TranslationEngine.Record> records = new ArrayList<>();
    private Spinner sourcePicker, targetPicker;
    private TextView status, sourceText, targetText, levelText, pairLabel;
    private Button mic, speak;
    private LinearLayout historyList;
    private TextToSpeech tts;
    private boolean requested, downloading, ttsReady, swapping;
    private int sourceIndex = 0, targetIndex = 1;
    private String latestTranslation = "";
    private int renderedHistoryRevision = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        sourceIndex = AppSettings.clamp(getPreferences(0).getInt("source", 0), 0, 7);
        targetIndex = AppSettings.clamp(getPreferences(0).getInt("target", 1), 0, 7);
        buildUi();
        tts = new TextToSpeech(this, result -> ttsReady = result == TextToSpeech.SUCCESS);
        bound = bindService(new Intent(this, TranslationService.class), connection, BIND_AUTO_CREATE);
    }

    private TranslationService service;
    private boolean bound, pendingOverlay;
    private final Runnable observer = this::renderEngine;
    private final android.content.ServiceConnection connection = new android.content.ServiceConnection() {
        @Override public void onServiceConnected(android.content.ComponentName name, android.os.IBinder binder) {
            if (!(binder instanceof TranslationService.LocalBinder)) { toast("翻译服务连接失败，请重新打开应用"); return; }
            service = ((TranslationService.LocalBinder)binder).getService(); bound = true;
            if (!service.hasOverlay()) service.engine.selectLanguages(sourceIndex, targetIndex);
            renderedHistoryRevision = -1; service.observer = observer; renderEngine();
        }
        @Override public void onServiceDisconnected(android.content.ComponentName name) { service = null; }
    };
    private void renderEngine() {
        if (service == null) return;
        TranslationEngine e = service.engine;
        swapping = true; sourceIndex = e.sourceIndex; targetIndex = e.targetIndex;
        if (sourcePicker.getSelectedItemPosition() != sourceIndex) sourcePicker.setSelection(sourceIndex);
        if (targetPicker.getSelectedItemPosition() != targetIndex) targetPicker.setSelection(targetIndex); swapping = false;
        requested = e.requested; downloading = e.downloading;
        if (!android.text.TextUtils.equals(sourceText.getText(), e.sourceText)) sourceText.setText(e.sourceText);
        if (!android.text.TextUtils.equals(targetText.getText(), e.targetText)) targetText.setText(e.targetText); latestTranslation = e.latestTranslation;
        pairLabel.setText(getString(R.string.language_pair, NAMES[sourceIndex], NAMES[targetIndex]));
        setStatus(e.status + (e.aiStatus.isEmpty() ? "" : "\n" + e.aiStatus));
        levelText.setText(meter(e.level)); updateMic();
        if (renderedHistoryRevision != e.historyRevision) {
            renderedHistoryRevision = e.historyRevision; records.clear(); records.addAll(e.records); renderHistory();
        }
    }

    private void buildUi() {
        LinearLayout root = column();
        root.setBackgroundColor(0xFFF6F8F5);
        root.setPadding(dp(22), dp(12), dp(22), dp(12));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                root.setPadding(dp(22) + bars.left, dp(12) + bars.top, dp(22) + bars.right, dp(12) + bars.bottom);
            } else {
                root.setPadding(dp(22) + insets.getSystemWindowInsetLeft(), dp(12) + insets.getSystemWindowInsetTop(), dp(22) + insets.getSystemWindowInsetRight(), dp(12) + insets.getSystemWindowInsetBottom());
            }
            return Build.VERSION.SDK_INT >= 30 ? WindowInsets.CONSUMED : insets.consumeSystemWindowInsets();
        });
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = column();
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.requestApplyInsets();

        LinearLayout brand = row();
        TextView logo = text("声译", 29, INK); logo.setTypeface(null, Typeface.BOLD);
        brand.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("LINGO LIVE", 11, GREEN);
        badge.setLetterSpacing(.16f); badge.setPadding(dp(12), dp(8), dp(12), dp(8));
        badge.setBackground(shape(0xFFE5EEE7, 18)); brand.addView(badge);
        content.addView(brand);
        TextView intro = text("让每一句话，都被听懂。", 14, MUTED);
        add(content, intro, 8, 24);

        LinearLayout languageCard = row();
        languageCard.setPadding(dp(4), dp(9), dp(4), dp(9));
        languageCard.setBackground(shape(Color.WHITE, 22));
        sourcePicker = picker(sourceIndex); targetPicker = picker(targetIndex);
        sourcePicker.setContentDescription("源语言"); targetPicker.setContentDescription("目标语言");
        languageCard.addView(sourcePicker, new LinearLayout.LayoutParams(0, dp(56), 1));
        Button swap = button("⇄", 0xFFEAF1EB, GREEN);
        swap.setTextSize(26); swap.setContentDescription("互换源语言与目标语言");
        languageCard.addView(swap, new LinearLayout.LayoutParams(dp(48), dp(48)));
        languageCard.addView(targetPicker, new LinearLayout.LayoutParams(0, dp(56), 1));
        add(content, languageCard, 0, 20);
        AdapterView.OnItemSelectedListener listener = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (swapping) return;
                int s = sourcePicker.getSelectedItemPosition(), t = targetPicker.getSelectedItemPosition();
                if (s != sourceIndex || t != targetIndex) {
                    sourceIndex = s; targetIndex = t; resetPair();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };
        sourcePicker.setOnItemSelectedListener(listener); targetPicker.setOnItemSelectedListener(listener);
        swap.setOnClickListener(v -> {
            swapping = true;
            int old = sourceIndex; sourceIndex = targetIndex; targetIndex = old;
            sourcePicker.setSelection(sourceIndex); targetPicker.setSelection(targetIndex);
            swapping = false; resetPair();
        });

        LinearLayout liveCard = column();
        liveCard.setPadding(dp(22), dp(22), dp(22), dp(22));
        liveCard.setBackground(shape(Color.WHITE, 24));
        pairLabel = text("实时语音翻译", 12, GREEN);
        pairLabel.setLetterSpacing(.06f); liveCard.addView(pairLabel);
        sourceText = text("点击下方按钮，开始说话", 23, INK);
        sourceText.setTextIsSelectable(true); sourceText.setMinHeight(dp(90));
        add(liveCard, sourceText, 18, 18);
        View divider = new View(this); divider.setBackgroundColor(0xFFE8EEE8);
        liveCard.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        TextView translationLabel = text("译文", 12, MUTED); add(liveCard, translationLabel, 18, 10);
        targetText = text("翻译会在这里实时呈现", 25, GREEN);
        targetText.setTextIsSelectable(true); targetText.setMinHeight(dp(90)); liveCard.addView(targetText);
        LinearLayout actions = row();
        Button copy = button("复制译文", 0xFFF0F5F0, GREEN);
        speak = button("朗读译文", 0xFFF0F5F0, GREEN);
        actions.addView(copy, new LinearLayout.LayoutParams(0, dp(46), 1));
        Space gap = new Space(this); actions.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        actions.addView(speak, new LinearLayout.LayoutParams(0, dp(46), 1));
        add(liveCard, actions, 20, 0);
        copy.setOnClickListener(v -> {
            if (latestTranslation.isEmpty()) { toast("还没有可复制的译文"); return; }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("译文", latestTranslation));
            toast("译文已复制");
        });
        speak.setOnClickListener(v -> readAloud());
        content.addView(liveCard);

        levelText = text("·  ·  ·  ·  ·  ·  ·", 24, GREEN);
        levelText.setGravity(Gravity.CENTER); add(content, levelText, 14, 2);
        status = text("准备就绪", 13, MUTED); status.setGravity(Gravity.CENTER);
        add(content, status, 0, 14);
        mic = button("开始实时翻译", GREEN, Color.WHITE); mic.setTextSize(17);
        add(content, mic, 0, 12); mic.getLayoutParams().height = dp(60);
        mic.setOnClickListener(v -> {
            if (requested) { stopSpeech(false); setStatus("已暂停，点击可继续"); }
            else begin();
        });
        TextView note = text("首次翻译需联网下载语言模型。语音识别由手机系统提供，可能需要联网并处理音频。仅已完成的翻译保存在本机，可随时清空。", 11, MUTED);
        note.setGravity(Gravity.CENTER); note.setLineSpacing(dp(3), 1); add(content, note, 0, 26);

        Button overlayButton = button("开启悬浮翻译", 0xFFE5EEE7, GREEN);
        add(content, overlayButton, 0, 10); overlayButton.setOnClickListener(v -> beginOverlay());
        Button settingsButton = button("悬浮窗与 GPT 校准设置", 0xFFE5EEE7, GREEN);
        add(content, settingsButton, 0, 22);
        settingsButton.setOnClickListener(v -> new SettingsDialog(this, () -> {
            if (service != null) service.refreshOverlay();
        }, () -> { if (service != null) service.engine.settingsChanged(); }).show());
        LinearLayout recent = row();
        TextView title = text("最近翻译", 18, INK); title.setTypeface(null, Typeface.BOLD);
        recent.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = button("清空", 0xFFF6F8F5, MUTED); recent.addView(clear);
        content.addView(recent);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("清空翻译记录？")
            .setMessage("删除保存在本机的所有翻译记录。")
            .setNegativeButton("取消", null).setPositiveButton("清空", (d, w) -> {
                if (service != null) service.engine.clearHistory();
            }).show());
        historyList = column(); add(content, historyList, 10, 8); renderHistory();
    }

    private void begin() { startTranslation(false); }
    private void beginOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this).setTitle("允许显示悬浮窗")
                .setMessage("开启后可在其他 APP 上显示实时语音译文。需要允许“显示在其他应用上层”，录音期间会显示麦克风通知。")
                .setNegativeButton("取消", null).setPositiveButton("去授权", (dialog, which) -> {
                    pendingOverlay = true;
                    try { startActivityForResult(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:" + getPackageName())), 30); }
                    catch (RuntimeException e) { pendingOverlay = false; toast("请在系统设置中授予悬浮窗权限"); }
                }).show(); return;
        }
        startTranslation(true);
    }
    private void startTranslation(boolean overlay) {
        if (service == null) { toast("翻译服务正在准备，请稍后重试"); return; }
        if (sourceIndex == targetIndex) { toast("请选择两种不同的语言"); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingOverlay = overlay;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10); return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !getPreferences(0).getBoolean("notification_asked", false)) {
            getPreferences(0).edit().putBoolean("notification_asked", true).apply(); pendingOverlay = overlay;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11); return;
        }
        tts.stop();
        try { startForegroundService(new Intent(this, TranslationService.class)
            .setAction(overlay ? TranslationService.OVERLAY : TranslationService.START)); }
        catch (RuntimeException e) { setStatus("无法启动翻译，请检查权限并保持应用在前台"); }
    }
    private void resetPair() {
        if (service != null) service.engine.selectLanguages(sourceIndex, targetIndex);
        else getPreferences(0).edit().putInt("source", sourceIndex).putInt("target", targetIndex).apply();
        if (tts != null) tts.stop();
        pairLabel.setText(getString(R.string.language_pair, NAMES[sourceIndex], NAMES[targetIndex]));
    }
    private void stopSpeech(boolean cancel) { if (service != null) service.pause(); }

    private void readAloud() {
        if (latestTranslation.isEmpty()) { toast("还没有可朗读的译文"); return; }
        if (!ttsReady) { toast("系统朗读引擎尚未就绪"); return; }
        stopSpeech(true);
        int result = tts.setLanguage(Locale.forLanguageTag(LOCALES[targetIndex]));
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            setStatus("系统缺少该语言的语音包，请在系统设置中安装"); return;
        }
        int queued = tts.speak(latestTranslation, TextToSpeech.QUEUE_FLUSH, null, "translation");
        setStatus(queued == TextToSpeech.SUCCESS ? "已暂停麦克风，正在朗读译文" : "朗读失败，请检查系统语音引擎");
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == 11) { boolean overlay = pendingOverlay; pendingOverlay = false; startTranslation(overlay); return; }
        if (code != 10) return;
        boolean overlay = pendingOverlay; pendingOverlay = false;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startTranslation(overlay);
        else setStatus("需要麦克风权限；可在系统设置 → 应用 → 声译中开启");
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == 30 && pendingOverlay) {
            pendingOverlay = false;
            if (android.provider.Settings.canDrawOverlays(this)) handler.post(() -> startTranslation(true));
            else toast("尚未授予悬浮窗权限");
        }
    }
    @Override protected void onPause() {
        super.onPause();
        if (service != null && !service.hasOverlay()) service.pause();
        if (tts != null) tts.stop();
    }
    @Override protected void onDestroy() {
        if (service != null && service.observer == observer) service.observer = null;
        if (bound) unbindService(connection);
        handler.removeCallbacksAndMessages(null);
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private String meter(int bars) {
        StringBuilder value = new StringBuilder();
        for (int i = 0; i < 7; i++) value.append(i < bars ? "▏" : "·");
        return value.toString();
    }
    private void updateMic() {
        mic.setText(requested ? (downloading ? "取消准备" : "停止聆听") : "开始实时翻译");
        mic.setBackground(shape(requested ? 0xFFA04332 : GREEN, 20));
    }
    private void setStatus(String value) { if (status != null) status.setText(value); }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout column() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); return v; }
    private LinearLayout row() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setLineSpacing(dp(3), 1); return v;
    }
    private Button button(String value, int background, int foreground) {
        Button v = new Button(this); v.setText(value); v.setTextColor(foreground); v.setTextSize(13);
        v.setAllCaps(false); v.setMinWidth(0); v.setMinimumWidth(0); v.setMinHeight(0); v.setMinimumHeight(dp(44));
        v.setPadding(dp(14), dp(8), dp(14), dp(8)); v.setStateListAnimator(null); v.setBackground(shape(background, 16)); return v;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable v = new GradientDrawable(); v.setColor(color); v.setCornerRadius(dp(radius)); return v;
    }
    private void add(LinearLayout parent, View view, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(top), 0, dp(bottom)); parent.addView(view, p);
    }
    private Spinner picker(int selected) {
        Spinner picker = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, NAMES);
        picker.setAdapter(adapter); picker.setSelection(selected); return picker;
    }
    private void renderHistory() {
        if (historyList == null) return;
        historyList.removeAllViews();
        if (records.isEmpty()) {
            TextView empty = text("还没有翻译记录\n开始一段跨越语言的对话吧", 13, MUTED);
            empty.setGravity(Gravity.CENTER); empty.setPadding(0, dp(20), 0, dp(20)); historyList.addView(empty); return;
        }
        for (TranslationEngine.Record record : records) {
            LinearLayout item = column(); item.setBackground(shape(Color.WHITE, 18)); item.setPadding(dp(18), dp(16), dp(18), dp(16));
            item.addView(text(record.pair, 11, MUTED));
            TextView original = text(record.source, 15, INK); original.setTextIsSelectable(true); add(item, original, 8, 6);
            TextView translated = text(record.target, 17, GREEN); translated.setTextIsSelectable(true); item.addView(translated);
            add(historyList, item, 0, 10);
        }
    }
}
