package com.lingolive.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.*;

final class SettingsDialog {
    private final Activity activity;
    private final AppSettings settings;
    private final Runnable changed, aiChanged;
    SettingsDialog(Activity activity, Runnable changed, Runnable aiChanged) { this.activity = activity; this.changed = changed; this.aiChanged = aiChanged; settings = new AppSettings(activity); }
    void show() {
        LinearLayout content = new LinearLayout(activity); content.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(20 * activity.getResources().getDisplayMetrics().density); content.setPadding(padding, padding, padding, padding);
        label(content, "悬浮窗设置即时生效，也可拖动标题移动、拖动右下角缩放。");
        slider(content, "窗口宽度", "width", settings.width(), 220, 600, " dp");
        slider(content, "窗口高度", "height", settings.height(), 180, 600, " dp");
        slider(content, "窗口明暗（不改变系统亮度）", "brightness", settings.brightness(), 20, 100, "%");
        slider(content, "译文字体大小", "font", settings.font(), 12, 36, " sp");
        CheckBox bilingual = new CheckBox(activity); bilingual.setText("双语显示（原文 + 译文）"); bilingual.setChecked(settings.bilingual()); content.addView(bilingual);
        bilingual.setOnCheckedChangeListener((v, value) -> { settings.prefs.edit().putBoolean("bilingual", value).apply(); changed.run(); });
        label(content, "GPT 译文校准 · 可选\n启用后仅发送完整句子的原文与本机初译到你配置的服务端，再由 OpenAI 校准；不发送音频。服务可能产生费用。失败时保留本机译文。");
        CheckBox ai = new CheckBox(activity); ai.setText(R.string.enable_gpt); ai.setChecked(settings.aiEnabled()); content.addView(ai);
        EditText endpoint = new EditText(activity); endpoint.setSingleLine(); endpoint.setHint("https://你的服务地址/calibrate"); endpoint.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        endpoint.setText(settings.endpoint()); content.addView(endpoint);
        EditText token = new EditText(activity); token.setSingleLine(); token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setHint("服务访问令牌（留空保留已存令牌）"); content.addView(token);
        label(content, "这里填写自建服务的访问令牌，不是 OpenAI API 密钥。令牌使用 Android Keystore 加密保存。");
        ScrollView scroll = new ScrollView(activity); scroll.addView(content);
        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("悬浮窗与 GPT 设置").setView(scroll)
            .setNegativeButton("关闭", null).setPositiveButton("保存 AI 设置", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            String url = endpoint.getText().toString().trim(), access = token.getText().toString().trim();
            if (ai.isChecked() && !AppSettings.validEndpoint(url)) { endpoint.setError("请输入以 /calibrate 结尾的 HTTPS 地址"); return; }
            if (access.startsWith("sk-")) { token.setError("请勿填写 OpenAI 密钥；填写自建服务的访问令牌"); return; }
            try {
                SecureTokenStore store = new SecureTokenStore(activity);
                if (ai.isChecked() && access.isEmpty() && store.read().isEmpty()) { token.setError("请填写服务端配置的访问令牌"); return; }
                if (!access.isEmpty()) store.save(access);
            } catch (Exception e) { token.setError("设备无法安全保存令牌，请检查系统密钥存储"); return; }
            settings.prefs.edit().putString("ai_endpoint", url).putBoolean("ai_enabled", ai.isChecked()).apply(); aiChanged.run(); dialog.dismiss();
        }));
        dialog.show();
    }
    private void label(LinearLayout parent, String text) {
        TextView view = new TextView(activity); view.setText(text); view.setTextSize(13); view.setPadding(0, 16, 0, 10); parent.addView(view);
    }
    private void slider(LinearLayout parent, String title, String key, int current, int min, int max, String unit) {
        TextView label = new TextView(activity); label.setText(activity.getString(R.string.setting_value, title, current, unit)); parent.addView(label);
        SeekBar seek = new SeekBar(activity); seek.setMax(max - min); seek.setProgress(current - min); seek.setContentDescription(title); parent.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean user) {
                int value = progress + min; label.setText(activity.getString(R.string.setting_value, title, value, unit));
                if (user) { settings.prefs.edit().putInt(key, value).apply(); changed.run(); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }
}
