package com.lingolive.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.provider.Settings;
import android.speech.SpeechRecognizer;
import android.widget.Toast;

/** Single owner for microphone, language models, and the floating window. Never auto-restarts recording. */
public class TranslationService extends Service {
    static final String START = "com.lingolive.START", OVERLAY = "com.lingolive.OVERLAY", STOP = "com.lingolive.STOP";
    private static final String CHANNEL = "live_translation";
    private final IBinder binder = new LocalBinder();
    TranslationEngine engine;
    FloatingTranslationWindow overlay;
    Runnable observer;
    private boolean foreground;
    final class LocalBinder extends Binder { TranslationService getService() { return TranslationService.this; } }
    @Override public void onCreate() {
        super.onCreate(); engine = new TranslationEngine(this);
        engine.listener = () -> {
            if (overlay != null) overlay.render();
            if (foreground && overlay == null && !engine.requested && !engine.downloading) finishForeground();
            if (observer != null) observer.run();
        };
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "实时翻译麦克风", NotificationManager.IMPORTANCE_LOW));
    }
    @Override public IBinder onBind(Intent intent) { return binder; }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || STOP.equals(intent.getAction())) { end(); return START_NOT_STICKY; }
        try {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                throw new SecurityException("Microphone permission missing");
            if (Build.VERSION.SDK_INT >= 30) startForeground(11, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(11, notification());
            foreground = true;
            if (OVERLAY.equals(intent.getAction())) {
                if (!Settings.canDrawOverlays(this)) throw new SecurityException("Overlay permission missing");
                if (overlay == null) { overlay = new FloatingTranslationWindow(this); overlay.show(); }
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                engine.status = "未找到语音识别服务，请在系统设置中启用";
                if (observer != null) observer.run(); end();
                Toast.makeText(this, "未找到语音识别服务", Toast.LENGTH_LONG).show();
            } else engine.begin();
        } catch (RuntimeException e) {
            end(); engine.status = "无法启动悬浮翻译，请检查麦克风、悬浮窗权限和系统限制";
            if (observer != null) observer.run();
            Toast.makeText(this, engine.status, Toast.LENGTH_LONG).show();
        }
        return START_NOT_STICKY;
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, TranslationService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("声译 · 实时翻译已开启").setContentText("麦克风可能正在使用中，点击返回或停止翻译")
            .setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null, "停止翻译", stop).build()).build();
    }
    boolean hasOverlay() { return overlay != null; }
    void refreshOverlay() { if (overlay != null) overlay.applySettings(); }
    void pause() { engine.pause(); if (overlay == null) finishForeground(); }
    void end() {
        if (overlay != null) { overlay.close(); overlay = null; }
        engine.pause(); finishForeground();
    }
    private void finishForeground() {
        if (foreground) { stopForeground(STOP_FOREGROUND_REMOVE); foreground = false; }
        stopSelf();
    }
    @Override public void onTaskRemoved(Intent rootIntent) { end(); super.onTaskRemoved(rootIntent); }
    @Override public void onConfigurationChanged(android.content.res.Configuration config) {
        super.onConfigurationChanged(config); refreshOverlay();
    }
    @Override public void onDestroy() {
        if (overlay != null) overlay.close();
        engine.close(); observer = null; super.onDestroy();
    }
}
