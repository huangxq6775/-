package com.lingolive.app;

import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = {26, 35})
public class OverlaySettingsTest {
    @Test public void overlayAppliesBilingualFontBrightnessAndStopsCleanly() {
        var controller = Robolectric.buildService(TranslationService.class).create();
        try {
            TranslationService service = controller.get();
            AppSettings settings = new AppSettings(service);
            settings.prefs.edit().clear().putInt("font", 30).putInt("brightness", 30).putBoolean("bilingual", false).apply();
            FloatingTranslationWindow window = new FloatingTranslationWindow(service);
            try {
                window.show();
                WindowManager.LayoutParams layout = ReflectionHelpers.getField(window, "params");
                assertEquals(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, layout.type);
                assertNotEquals(0, layout.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
                TextView original = ReflectionHelpers.getField(window, "original");
                TextView translated = ReflectionHelpers.getField(window, "translation");
                assertEquals(View.GONE, original.getVisibility());
                assertEquals(30 * service.getResources().getDisplayMetrics().scaledDensity, translated.getTextSize(), .1f);
                service.engine.sourceText = "नमस्ते"; service.engine.targetText = "你好"; window.render();
                assertEquals("你好", translated.getText().toString());
                settings.prefs.edit().putBoolean("bilingual", true).putInt("width", 260).apply(); window.applySettings();
                assertEquals(View.VISIBLE, original.getVisibility());
                assertEquals("नमस्ते", original.getText().toString());
            } finally { window.close(); }
            service.end();
            assertFalse(service.engine.requested);
            assertFalse(service.hasOverlay());
        } finally { controller.destroy(); }
    }
    @Test public void languageChangeKeepsSavedHistoryButInvalidatesOldResult() {
        Context context = RuntimeEnvironment.getApplication();
        context.getSharedPreferences("MainActivity", 0).edit().clear()
            .putString("history", "[{\"source\":\"hello\",\"target\":\"你好\",\"pair\":\"English → 中文\"}]").apply();
        try (TranslationEngine engine = new TranslationEngine(context)) {
            assertEquals(1, engine.records.size());
            long previous = engine.revision.next();
            engine.selectLanguages(7, 0);
            assertFalse(engine.revision.isCurrent(previous));
            assertEquals(1, engine.records.size());
            assertEquals(7, context.getSharedPreferences("MainActivity", 0).getInt("source", -1));
            engine.clearHistory();
            assertEquals("[]", context.getSharedPreferences("MainActivity", 0).getString("history", ""));
        }
    }
    @Test public void calibrationRequiresHttpsAndRejectsEmbeddedCredentials() {
        assertTrue(AppSettings.validEndpoint("https://translate.example.com/calibrate"));
        assertFalse(AppSettings.validEndpoint("http://translate.example.com/calibrate"));
        assertFalse(AppSettings.validEndpoint("https://secret@translate.example.com/calibrate"));
        assertFalse(AppSettings.validEndpoint("https://translate.example.com/calibrate?token=secret"));
        assertFalse(AppSettings.validEndpoint("https://translate.example.com/calibrate#fragment"));
    }
}
