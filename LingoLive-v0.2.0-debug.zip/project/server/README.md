# GPT 译文校准服务

Python 3.11+，仅使用标准库，无第三方 Python 依赖。手机发送完整原文和端侧初译，服务调用 OpenAI Responses API 返回校准译文，不接收音频。

## 配置与本机启动

1. 将 `.env.example` 复制为 `.env`，在服务器上填写 `OPENAI_API_KEY`。
2. 用 `openssl rand -hex 32` 生成独立的 `APP_ACCESS_TOKEN`。不要把 OpenAI API 密钥填写到手机或提交到 Git。
3. `OPENAI_MODEL` 默认 `gpt-4.1-mini`，可换成你的账户可用且支持 Responses API 的模型。

```bash
cd server
set -a
. ./.env
set +a
python3 server.py
```

默认只监听 `127.0.0.1:8787`。`GET /health` 返回 `{"status":"ok"}` 只表明 HTTP 服务存活，**不证明 OpenAI 凭据、额度或模型可用**。

## Docker 部署（可选）

```bash
cd server
docker build -t lingolive-calibration .
docker run -d --name lingolive-calibration --restart unless-stopped \
  --env-file .env -p 127.0.0.1:8787:8787 lingolive-calibration
```

为此服务配置一个公网域名和可信 HTTPS 证书，通过 Nginx 或 Caddy 反向代理到本机 8787 端口。例如 Caddy：

```caddy
translate.your-domain.com {
    reverse_proxy 127.0.0.1:8787
}
```

将示例域名换成你的真实域名，并配置 DNS。不要直接向公网开放 8787 明文端口。生产部署应由反向代理限制连接并发、请求体为 32 KB、请求超时及访问日志中的敏感字段。容器镜像及 HTTPS 代理部署须在自己的服务器验证，本仓库的 HTTP 服务测试不等于完成上线部署。

服务端需要访问 `api.openai.com:443`。Android 客户端仅需访问你自建的 HTTPS 域名；不要关闭 TLS 校验。

## 手机设置

在「悬浮窗与 GPT 校准设置」中填写：

- 服务地址：`https://你的域名/calibrate`
- 访问令牌：服务端 `APP_ACCESS_TOKEN` 的同一个值
- 打开 GPT 校准开关，并点击「保存 AI 设置」。

OpenAI API 密钥仅保存在服务器。手机只保存自建服务令牌，以 Android Keystore 加密。关闭 AI 开关则不再发起新的校准请求；已经到达服务器的请求可能已产生费用，客户端取消不会保证远端请求未被计费。

## 接口与行为

`POST /calibrate`，头部 `Authorization: Bearer <APP_ACCESS_TOKEN>`、`Content-Type: application/json`。

```json
{
  "source": "你好",
  "translation": "नमस्ते",
  "source_language": "中文",
  "target_language": "हिन्दी"
}
```

成功返回 `{"translation":"校准后的译文"}`。仅支持 APP 中的八种语言标签。认证失败返回 401，格式错误返回 400/413/415，繁忙或限流返回 429，上游失败返回 502。默认最多两条校准并行、每个实例每分钟 30 次请求，适合个人或小规模测试；多用户部署需独立身份认证和按用户计费/限流。

请求设置 `store: false`，本服务不记录文本、令牌或上游错误内容。OpenAI 对数据的处理仍按账户及其服务政策执行。模型结果仅作译文校准，客户端在错误、超时或断网时保留端侧译文。

## 测试

```bash
cd server
python3 -m unittest -v test_server
```

测试通过本地 HTTP 请求和替身上游验证认证、限流、印地语响应、错误回退及 Responses API 请求结构；不会消耗真实 OpenAI 额度。真实 GPT 校准还需配置真实密钥、可用模型、额度与 HTTPS 域名后，在手机说一句话完成端到端验收。
