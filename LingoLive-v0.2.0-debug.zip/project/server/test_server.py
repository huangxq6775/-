import http.client
import json
import threading
import unittest
from unittest.mock import patch
from server import CalibrationServer, UpstreamError, calibrate, validate_payload

TOKEN = "test-only-access-" + "x" * 32
DATA = {"source": "你好", "translation": "नमस्ते", "source_language": "中文", "target_language": "हिन्दी"}


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        def translate(data, key, model):
            self.calls.append(data)
            return "नमस्ते!"
        self.server = CalibrationServer(("127.0.0.1", 0), "test-key-not-real", TOKEN, translator=translate)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join()

    def request(self, data=DATA, token=TOKEN, path="/calibrate", method="POST", headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=3)
        body = json.dumps(data).encode()
        metadata = {"Content-Type": "application/json", "Authorization": "Bearer " + token}
        metadata.update(headers or {})
        try:
            connection.request(method, path, body, metadata)
            response = connection.getresponse()
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def test_health(self):
        self.assertEqual(self.request(path="/health", method="GET"), (200, {"status": "ok"}))
        self.assertEqual(self.calls, [])

    def test_hindi_calibration_response(self):
        self.assertEqual(self.request(), (200, {"translation": "नमस्ते!"}))
        self.assertEqual(self.calls, [DATA])

    def test_authentication_precedes_upstream(self):
        self.assertEqual(self.request(token="wrong")[0], 401)
        self.assertEqual(self.calls, [])

    def test_invalid_language_and_text(self):
        for invalid in ({**DATA, "target_language": "xx"}, {**DATA, "source": ""}, {**DATA, "source": "x" * 4001}):
            self.assertEqual(self.request(invalid)[0], 400)
        self.assertEqual(self.calls, [])

    def test_oversize_request_rejected(self):
        self.assertEqual(self.request({**DATA, "source": "x" * 33000})[0], 413)
        self.assertEqual(self.calls, [])

    def test_wrong_content_type(self):
        self.assertEqual(self.request(headers={"Content-Type": "text/plain"})[0], 415)

    def test_rate_limit(self):
        for _ in range(30): self.assertEqual(self.request()[0], 200)
        self.assertEqual(self.request()[0], 429)
        self.assertEqual(len(self.calls), 30)

    def test_upstream_outage_does_not_leak_errors(self):
        def fail(*args): raise UpstreamError("private upstream diagnostic")
        self.server.translator = fail
        self.assertEqual(self.request(), (502, {"error": "calibration_unavailable"}))

    def test_responses_api_contract(self):
        captured = []
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, limit):
                return json.dumps({"status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": "नमस्ते"}]}]}).encode()
        def urlopen(request, timeout):
            captured.append(json.loads(request.data)); return Response()
        with patch("server.urllib.request.urlopen", urlopen):
            self.assertEqual(calibrate(DATA, "not-real", "gpt-4.1-mini"), "नमस्ते")
        self.assertFalse(captured[0]["store"])
        self.assertEqual(json.loads(captured[0]["input"][1]["content"]), DATA)
        self.assertEqual(captured[0]["input"][0]["role"], "developer")

    def test_incomplete_gpt_output_not_accepted(self):
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, limit): return b'{"status":"incomplete","output":[]}'
        with patch("server.urllib.request.urlopen", return_value=Response()):
            with self.assertRaises(UpstreamError): calibrate(DATA, "not-real", "gpt-4.1-mini")


if __name__ == "__main__": unittest.main()
