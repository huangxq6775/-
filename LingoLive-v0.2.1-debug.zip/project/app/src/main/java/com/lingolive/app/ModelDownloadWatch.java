package com.lingolive.app;

import android.os.Handler;

/** Bounds the UI wait, not the SDK download. Late results can never restart recording. */
final class ModelDownloadWatch {
    interface Completion { void ready(); void failed(Exception error); }
    interface Loader { void load(Completion completion); }
    interface Listener { void ready(); void failed(Exception error); void timedOut(); }
    private final Handler handler;
    private final long timeoutMs;
    private long generation;
    private boolean active;
    private Runnable timeout;
    ModelDownloadWatch(Handler handler, long timeoutMs) { this.handler = handler; this.timeoutMs = timeoutMs; }
    void start(Loader loader, Listener listener) {
        cancel(); long ticket = generation; active = true;
        timeout = () -> { if (finish(ticket)) listener.timedOut(); };
        handler.postDelayed(timeout, timeoutMs);
        try {
            loader.load(new Completion() {
                @Override public void ready() { handler.post(() -> { if (finish(ticket)) listener.ready(); }); }
                @Override public void failed(Exception error) { handler.post(() -> { if (finish(ticket)) listener.failed(error); }); }
            });
        } catch (RuntimeException error) {
            if (finish(ticket)) listener.failed(error);
        }
    }
    private boolean finish(long ticket) {
        if (!active || ticket != generation) return false;
        active = false; handler.removeCallbacks(timeout); timeout = null; return true;
    }
    void cancel() {
        generation++; active = false;
        if (timeout != null) handler.removeCallbacks(timeout);
        timeout = null;
    }
}
