package com.lingolive.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.*;

/** Records preparation stages only; never audio, translations, access tokens, or API keys. */
final class DownloadDiagnostics {
    private final Context context;
    private final android.content.SharedPreferences prefs;
    DownloadDiagnostics(Context context) { this.context = context; prefs = context.getSharedPreferences("model_diagnostics", 0); }
    synchronized void record(String stage) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        String history = prefs.getString("stages", "") + time + "  " + stage + "\n";
        String[] lines = history.split("\n");
        if (lines.length > 30) history = String.join("\n", Arrays.copyOfRange(lines, lines.length - 30, lines.length)) + "\n";
        prefs.edit().putString("stages", history).apply();
    }
    String snapshot() {
        String version;
        try { version = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName; }
        catch (Exception e) { version = "未知"; }
        String network = "未检测到活动网络";
        try {
            ConnectivityManager cm = context.getSystemService(ConnectivityManager.class);
            NetworkCapabilities n = cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (n != null) network = "Internet能力=" + n.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                + ", 系统验证=" + n.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                + ", VPN=" + n.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
                + ", WiFi=" + n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                + ", 移动网络=" + n.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
        } catch (RuntimeException e) { network = "网络信息读取失败"; }
        return "声译版本：" + version + "\n设备：" + Build.MANUFACTURER + " " + Build.MODEL + " / Android API " + Build.VERSION.SDK_INT
            + "\nML Kit translate：17.0.3\n" + network
            + "\n注意：SDK 接口返回不代表已发出网络请求。这里没有下载字节统计，也未证明 Google 服务可达。\n\n"
            + prefs.getString("stages", "尚未尝试准备模型");
    }
}
