package com.lingolive.app;

import android.os.Handler;
import android.os.SystemClock;
import java.util.concurrent.*;

/** UI deadlines must remain independent of synchronous SDK initialization/download calls. */
final class ModelDownloadWatch implements AutoCloseable {
    interface Completion {
        void ready(); void failed(Exception error);
        default boolean isCurrent() { return true; }
    }
    interface Loader { void load(Completion completion); }
    interface Listener {
        void ready(); void failed(Exception error); void timedOut();
        default void waiting(long elapsedMs) { }
    }
    private final Handler handler;
    private final long timeoutMs;
    private final Executor worker;
    private volatile long generation;
    private volatile boolean active;
    private long started;
    private Runnable tick;
    ModelDownloadWatch(Handler handler, long timeoutMs) {
        this(handler, timeoutMs, new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(1), task -> { Thread t = new Thread(task, "model-preparation"); t.setDaemon(true); return t; }));
    }
    ModelDownloadWatch(Handler handler, long timeoutMs, Executor worker) { this.handler = handler; this.timeoutMs = timeoutMs; this.worker = worker; }
    void start(Loader loader, Listener listener) {
        cancel(); long ticket = generation; active = true; started = SystemClock.elapsedRealtime();
        tick = () -> {
            if (!current(ticket)) return;
            long elapsed = SystemClock.elapsedRealtime() - started;
            if (elapsed >= timeoutMs) { if (finish(ticket)) listener.timedOut(); }
            else { listener.waiting(elapsed); if (current(ticket)) handler.postDelayed(tick, Math.min(1000, timeoutMs - elapsed)); }
        };
        handler.postDelayed(tick, Math.min(1000, timeoutMs));
        Completion completion = new Completion() {
            @Override public boolean isCurrent() { return current(ticket); }
            @Override public void ready() { handler.post(() -> { if (finish(ticket)) listener.ready(); }); }
            @Override public void failed(Exception error) { handler.post(() -> { if (finish(ticket)) listener.failed(error); }); }
        };
        try {
            worker.execute(() -> {
                if (!current(ticket)) return;
                try { loader.load(completion); }
                catch (RuntimeException error) { completion.failed(error); }
            });
        } catch (RejectedExecutionException error) { completion.failed(error); }
    }
    private boolean current(long ticket) { return active && ticket == generation; }
    private boolean finish(long ticket) {
        if (!current(ticket)) return false;
        active = false; handler.removeCallbacks(tick); tick = null; return true;
    }
    void checkDeadline() { if (active && tick != null) { handler.removeCallbacks(tick); tick.run(); } }
    void cancel() {
        generation++; active = false;
        if (tick != null) handler.removeCallbacks(tick);
        tick = null;
        if (worker instanceof ThreadPoolExecutor) ((ThreadPoolExecutor)worker).getQueue().clear();
    }
    @Override public void close() { cancel(); if (worker instanceof ExecutorService) ((ExecutorService)worker).shutdownNow(); }
}
