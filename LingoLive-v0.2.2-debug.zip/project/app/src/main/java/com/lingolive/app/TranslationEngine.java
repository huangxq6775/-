package com.lingolive.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.*;
import org.json.*;
import java.util.*;

/** Owned by the foreground service, so activity recreation never duplicates microphone capture. */
final class TranslationEngine implements AutoCloseable {
    static final String[] NAMES = {"中文", "English", "日本語", "한국어", "Français", "Deutsch", "Español", "हिन्दी"};
    static final String[] CODES = {"zh", "en", "ja", "ko", "fr", "de", "es", "hi"};
    static final String[] LOCALES = {"zh-CN", "en-US", "ja-JP", "ko-KR", "fr-FR", "de-DE", "es-ES", "hi-IN"};
    final List<Record> records = new ArrayList<>();
    final Context context;
    final SharedPreferences preferences;
    final Handler handler = new Handler(Looper.getMainLooper());
    final TranslationRevision revision = new TranslationRevision();
    final AiCalibrationClient ai;
    final ModelDownloadWatch modelWatch = new ModelDownloadWatch(handler, 120_000);
    Runnable listener;
    SpeechRecognizer recognizer;
    volatile Translator translator;
    private final Object clientLock = new Object();
    volatile String modelPhase = "等待后台准备线程";
    final DownloadDiagnostics diagnostics;
    boolean requested, modelReady, downloading, destroyed;
    int sourceIndex, targetIndex, pairGeneration, speechGeneration, historyEpoch, level, historyRevision;
    String sourceText = "点击下方按钮，开始说话", targetText = "翻译会在这里实时呈现";
    String status = "点击开始 · 首次使用会下载语言模型", aiStatus = "", lastPartial = "", latestTranslation = "";
    Runnable pendingPartial;

    TranslationEngine(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences("MainActivity", Context.MODE_PRIVATE);
        sourceIndex = Math.max(0, Math.min(7, preferences.getInt("source", 0)));
        targetIndex = Math.max(0, Math.min(7, preferences.getInt("target", 1)));
        ai = new AiCalibrationClient(context, handler);
        diagnostics = new DownloadDiagnostics(context);
        readHistory();
    }
    void begin() {
        if (destroyed || requested) return;
        if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            setStatus("请在系统设置中允许麦克风权限"); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { setStatus("未找到语音识别服务"); return; }
        if (sourceIndex == targetIndex) { setStatus("请选择两种不同的语言"); return; }
        requested = true; aiStatus = ""; updateMic();
        if (modelReady) startSpeech(); else prepareModel();
    }
    void selectLanguages(int source, int target) {
        if (source == sourceIndex && target == targetIndex) return;
        stopSpeech(true); revision.next(); ai.cancel();
        Translator old;
        synchronized (clientLock) { pairGeneration++; modelWatch.cancel(); old = translator; translator = null; }
        if (old != null) old.close();
        sourceIndex = source; targetIndex = target;
        modelReady = false; downloading = false;
        latestTranslation = ""; aiStatus = "";
        sourceText = "点击下方按钮，开始说话"; targetText = "翻译会在这里实时呈现";
        preferences.edit().putInt("source", source).putInt("target", target).apply();
        setStatus(source == target ? "请选择两种不同的语言" : "点击开始 · 首次使用会下载语言模型");
    }
    void clearHistory() { historyEpoch++; ai.cancel(); aiStatus = ""; records.clear(); saveHistory(); changed(); }
    void settingsChanged() {
        ai.cancel(); aiStatus = ""; revision.next(); changed();
    }
    private void changed() { if (!destroyed && listener != null) listener.run(); }
    private void updateMic() { changed(); }
    private void setStatus(String value) { status = value; changed(); }
    void pause() { stopSpeech(true); setStatus("已暂停，点击可继续"); }
    private void prepareModel() {
        if (downloading) return;
        downloading = true;
        setStatus("正在准备 " + NAMES[sourceIndex] + " → " + NAMES[targetIndex] + " 语言模型（最多等待 2 分钟）");
        updateMic();
        final int generation = pairGeneration;
        final String from = CODES[sourceIndex], to = CODES[targetIndex];
        modelPhase = "等待后台准备线程";
        diagnostics.record("开始准备 " + from + " → " + to);
        modelWatch.start(completion -> {
            Translator client;
            synchronized (clientLock) { client = translator; }
            if (client == null) {
                modelPhase = "正在创建翻译客户端"; diagnostics.record(modelPhase);
                Translator candidate = Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build());
                boolean accepted;
                synchronized (clientLock) {
                    accepted = completion.isCurrent() && generation == pairGeneration;
                    if (accepted) translator = candidate;
                }
                if (!accepted) { candidate.close(); return; }
                client = candidate;
                diagnostics.record("翻译客户端已创建");
            }
            if (!completion.isCurrent()) return;
            modelPhase = "正在调用 SDK 下载接口"; diagnostics.record(modelPhase);
            client.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> completion.ready()).addOnFailureListener(completion::failed);
            if (completion.isCurrent()) { modelPhase = "SDK 接口已返回，等待完成回调"; diagnostics.record(modelPhase); }
        }, new ModelDownloadWatch.Listener() {
            @Override public void waiting(long elapsed) {
                setStatus("语言模型准备中：" + (elapsed / 1000) + "/120 秒\n" + modelPhase);
            }
            @Override public void ready() {
                diagnostics.record("模型准备成功");
                downloading = false; modelReady = true; updateMic();
                if (requested) startSpeech(); else setStatus("语言模型已就绪，点击开始翻译");
            }
            @Override public void failed(Exception error) {
                String code = error instanceof com.google.mlkit.common.MlKitException
                    ? "ML Kit 错误码 " + ((com.google.mlkit.common.MlKitException)error).getErrorCode()
                    : error.getClass().getSimpleName();
                diagnostics.record("SDK 失败：" + code);
                modelUnavailable("语言模型下载失败（" + code + "）。请检查加速范围和可用存储空间，再点击开始重试。");
            }
            @Override public void timedOut() {
                diagnostics.record("120 秒超时；最后阶段：" + modelPhase);
                modelUnavailable("准备超时：" + modelPhase + "。请打开“下载诊断”复制记录，点击开始可重试。SDK 后台任务可能仍在继续。");
            }
        });
    }
    private void modelUnavailable(String message) {
        downloading = false; modelReady = false; stopSpeech(true);
        latestTranslation = ""; targetText = "语言模型未就绪，暂不能翻译"; setStatus(message);
    }

    private void startSpeech() {
        if (!requested || destroyed || !modelReady) return;
        if (recognizer != null) recognizer.destroy();
        int generation = ++speechGeneration;
        lastPartial = ""; aiStatus = "";
        recognizer = SpeechRecognizer.createSpeechRecognizer(context);
        recognizer.setRecognitionListener(new RecognitionListener() {
            private boolean valid() { return !destroyed && generation == speechGeneration; }
            @Override public void onReadyForSpeech(Bundle params) { if (valid()) setStatus("正在聆听 · 请说" + NAMES[sourceIndex]); }
            @Override public void onBeginningOfSpeech() { if (valid()) setStatus("正在识别，译文会持续更新…"); }
            @Override public void onRmsChanged(float rms) {
                if (!valid()) return;
                int bars = Math.max(1, Math.min(7, (int)((rms + 2) / 2)));
                level = bars; changed();
            }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { if (valid()) setStatus("正在完成这一句…"); }
            @Override public void onPartialResults(Bundle results) {
                if (!valid() || !requested) return;
                String value = first(results);
                if (value.isEmpty() || value.equals(lastPartial)) return;
                lastPartial = value; sourceText = value; changed();
                revision.next();
                if (pendingPartial == null) {
                    pendingPartial = () -> {
                        pendingPartial = null;
                        translate(lastPartial, false, revision.next());
                    };
                    handler.postDelayed(pendingPartial, 250);
                }
            }
            @Override public void onResults(Bundle results) {
                if (!valid()) return;
                if (pendingPartial != null) { handler.removeCallbacks(pendingPartial); pendingPartial = null; }
                String value = first(results);
                if (value.isEmpty()) value = lastPartial;
                if (!value.isEmpty()) {
                    sourceText = value; changed(); translate(value, true, revision.next());
                }
                level = 0; changed();
                if (requested) scheduleRestart(generation, 400);
                else setStatus("已暂停，点击可继续");
            }
            @Override public void onError(int error) {
                if (!valid()) return;
                if (!requested) { setStatus("已暂停，点击可继续"); return; }
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    setStatus("没有听清，继续聆听…"); scheduleRestart(generation, 700); return;
                }
                requested = false; updateMic();
                String message;
                switch (error) {
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: message = "语音服务网络异常，请检查网络后重试"; break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: message = "请在系统设置中允许麦克风权限"; break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: message = "语音服务正忙，请稍后重试"; break;
                    case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                    case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: message = "系统语音服务暂不支持此语言，请下载对应语言或切换服务"; break;
                    case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS: message = "语音请求过于频繁，请稍后重试"; break;
                    default: message = "语音服务暂不可用（" + error + "），点击重试";
                }
                setStatus(message);
            }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, LOCALES[sourceIndex]);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { recognizer.startListening(intent); }
        catch (RuntimeException e) {
            requested = false; updateMic(); setStatus("无法启动语音服务，请检查系统设置");
        }
    }

    private void scheduleRestart(int generation, int delay) {
        handler.postDelayed(() -> { if (requested && generation == speechGeneration && !destroyed) startSpeech(); }, delay);
    }

    void stopSpeech(boolean cancel) {
        requested = false;
        if (pendingPartial != null) { handler.removeCallbacks(pendingPartial); pendingPartial = null; }
        if (cancel) speechGeneration++;
        if (recognizer != null) {
            if (cancel) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
            else recognizer.stopListening();
        }
        updateMic();
        level = 0; changed();
    }

    private void translate(String value, boolean complete, long ticket) {
        if (translator == null || !modelReady) return;
        int generation = pairGeneration, epoch = historyEpoch;
        String from = NAMES[sourceIndex], to = NAMES[targetIndex];
        translator.translate(value).addOnSuccessListener(result -> {
            if (destroyed || generation != pairGeneration) return;
            if (revision.isCurrent(ticket)) { latestTranslation = result; targetText = result; changed(); }
            if (complete && epoch == historyEpoch) {
                records.add(0, new Record(value, result, from + " → " + to));
                while (records.size() > 30) records.remove(records.size() - 1);
                saveHistory(); changed();
                if (revision.isCurrent(ticket)) calibrate(value, result, ticket, generation, epoch, records.get(0));
            }
        }).addOnFailureListener(error -> {
            if (!destroyed && generation == pairGeneration && revision.isCurrent(ticket)) {
                latestTranslation = ""; targetText = "翻译失败，请重新说一次"; changed();
            }
        });
    }


    private void calibrate(String source, String draft, long ticket, int generation, int epoch, Record record) {
        AppSettings settings = new AppSettings(context);
        if (!settings.aiEnabled()) return;
        aiStatus = "GPT 校准中 · 当前显示本机译文"; changed();
        ai.calibrate(source, draft, NAMES[sourceIndex], NAMES[targetIndex], (result, error) -> {
            if (destroyed || generation != pairGeneration || epoch != historyEpoch) return;
            if (error != null) {
                if (revision.isCurrent(ticket)) { aiStatus = error + " · 已保留本机译文"; changed(); }
                return;
            }
            if (!records.contains(record)) return;
            record.target = result; saveHistory();
            if (revision.isCurrent(ticket)) { targetText = result; latestTranslation = result; aiStatus = "GPT 已校准"; }
            changed();
        });
    }
    private static String first(Bundle bundle) {
        ArrayList<String> matches = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return matches == null || matches.isEmpty() ? "" : matches.get(0).trim();
    }
    @Override public void close() {
        Translator old;
        synchronized (clientLock) { modelWatch.close(); old = translator; translator = null; }
        stopSpeech(true); destroyed = true; handler.removeCallbacksAndMessages(null); ai.close();
        if (old != null) old.close();
        listener = null;
    }
    private void readHistory() {
        try {
            JSONArray data = new JSONArray(preferences.getString("history", "[]"));
            for (int i = 0; i < Math.min(data.length(), 30); i++) {
                JSONObject v = data.getJSONObject(i); records.add(new Record(v.getString("source"), v.getString("target"), v.getString("pair")));
            }
        } catch (JSONException ignored) { records.clear(); }
    }
    private void saveHistory() {
        historyRevision++;
        JSONArray data = new JSONArray();
        for (Record record : records) {
            JSONObject v = new JSONObject();
            try { v.put("source", record.source); v.put("target", record.target); v.put("pair", record.pair); data.put(v); }
            catch (JSONException ignored) { }
        }
        preferences.edit().putString("history", data.toString()).apply();
    }
    static class Record {
        final String source, pair;
        String target;
        Record(String source, String target, String pair) { this.source = source; this.target = target; this.pair = pair; }
    }
}
