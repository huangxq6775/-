package com.lingolive.app;

import android.os.Handler;
import android.os.Looper;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = {26, 35})
public class ModelDownloadWatchTest {
    final List<String> events = new ArrayList<>();
    final ModelDownloadWatch.Listener listener = new ModelDownloadWatch.Listener() {
        public void ready() { events.add("ready"); }
        public void failed(Exception error) { events.add("failed"); }
        public void timedOut() { events.add("timeout"); }
    };
    @Test public void stalledDownloadTimesOutAndLateSuccessCannotRestartMicrophone() {
        ModelDownloadWatch watch = new ModelDownloadWatch(new Handler(Looper.getMainLooper()), 120_000, Runnable::run);
        ModelDownloadWatch.Completion[] pending = new ModelDownloadWatch.Completion[1];
        watch.start(callback -> pending[0] = callback, listener);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(119)); assertTrue(events.isEmpty());
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1)); assertEquals(List.of("timeout"), events);
        pending[0].ready(); shadowOf(Looper.getMainLooper()).idle();
        assertEquals(List.of("timeout"), events);
    }
    @Test public void retryRejectsPreviousAttemptResults() {
        ModelDownloadWatch watch = new ModelDownloadWatch(new Handler(Looper.getMainLooper()), 120_000, Runnable::run);
        ModelDownloadWatch.Completion[] old = new ModelDownloadWatch.Completion[1];
        watch.start(callback -> old[0] = callback, listener);
        watch.start(ModelDownloadWatch.Completion::ready, listener);
        old[0].failed(new Exception("old")); shadowOf(Looper.getMainLooper()).idle();
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(3));
        assertEquals(List.of("ready"), events);
    }
    @Test public void languageChangeOrDestroyCancelsTimeoutAndCallbacks() {
        ModelDownloadWatch watch = new ModelDownloadWatch(new Handler(Looper.getMainLooper()), 120_000, Runnable::run);
        ModelDownloadWatch.Completion[] pending = new ModelDownloadWatch.Completion[1];
        watch.start(callback -> pending[0] = callback, listener); watch.cancel();
        pending[0].ready(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(3));
        assertTrue(events.isEmpty());
    }
    @Test public void immediateSdkFailureIsReportedOnce() {
        ModelDownloadWatch watch = new ModelDownloadWatch(new Handler(Looper.getMainLooper()), 120_000, Runnable::run);
        watch.start(callback -> { throw new IllegalStateException("sdk setup"); }, listener);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(3));
        assertEquals(List.of("failed"), events);
    }
    @Test public void synchronousSdkStallCannotBlockUiTimeout() throws Exception {
        java.util.concurrent.CountDownLatch entered = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch release = new java.util.concurrent.CountDownLatch(1);
        try (ModelDownloadWatch watch = new ModelDownloadWatch(new Handler(Looper.getMainLooper()), 120_000)) {
            watch.start(callback -> {
                entered.countDown();
                try { release.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                callback.ready();
            }, listener);
            try {
                assertTrue(entered.await(3, java.util.concurrent.TimeUnit.SECONDS));
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(2));
                assertEquals(List.of("timeout"), events);
            } finally { release.countDown(); }
        }
        shadowOf(Looper.getMainLooper()).idle();
        assertEquals(List.of("timeout"), events);
    }
}
